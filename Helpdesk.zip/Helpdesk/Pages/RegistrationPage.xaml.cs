﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Helpdesk.Pages
{
    public partial class RegistrationPage : Page
    {
        DBEntities db = new DBEntities();
        public RegistrationPage()
        {
            InitializeComponent();
        }

        private void registrationButton_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(loginBox.Text) && !string.IsNullOrEmpty(PhoneBox.Text) && PasswordBox.Password == RepeatPasswordBox.Password)
            {
                Users user = new Users()
                {
                    UserID = db.Users.Max(x => x.UserID) + 1,
                    LastName = "z",
                    FirstName = "x",
                    Patronymic = "c",
                    Email = loginBox.Text,
                    PhoneNumber = PhoneBox.Text,
                    Password = PasswordBox.Password,
                    RoleID = 1,
                    
                };
                db.Users.Add(user);
                db.SaveChanges();

                this.NavigationService.Navigate(new UserPage());
            }
            else
            {
                MessageBox.Show("Не все поля заполнены!");
            }
        }
    }
}
