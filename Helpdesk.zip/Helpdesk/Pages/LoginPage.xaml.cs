﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Helpdesk.Pages
{
    public partial class LoginPage : Page
    {
        DBEntities db = new DBEntities();
        public LoginPage()
        {
            InitializeComponent();
        }

        private void inputButton_Click(object sender, RoutedEventArgs e)
        {
            var userObj = db.Users.Where(x => x.Email == loginBox.Text && x.Password == PasswordBox.Password).FirstOrDefault();
            if (userObj != null)
            {
                switch (userObj.RoleID)
                {
                    case 1:
                        this.NavigationService.Navigate(new UserPage());
                        break;
                    case 2:
                        this.NavigationService.Navigate(new ManagerPage());
                        break;
                    case 3:
                        this.NavigationService.Navigate(new AdminPage());
                        break;
                }
            }
        }
    }
}